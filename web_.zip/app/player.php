<?php
require_once __DIR__ . "/auth.php";
require_once __DIR__ . "/config.php";
require_once __DIR__ . "/signed_url.php";

include __DIR__ . "/_header.php";
$name = $_SESSION['user_name'];

$rows = db()->query("SELECT * FROM media ORDER BY id DESC")->fetchAll();
?>

<h1>🎧 Global Media Player</h1>
<p><b><?= htmlspecialchars($name) ?></b>님 환영합니다.</p>
<a class="btn" href="/app/logout.php">로그아웃</a>

<div style="text-align:left;margin-top:15px;">
<?php foreach ($rows as $m): 
  $signed = cloudfront_signed_url("/{$m['s3_key']}", 3600); // 1시간 유효
?>
  <div class="alert">
    <b><?= htmlspecialchars($m['title']) ?></b><br>
    <?php if ($m['media_type'] === 'audio'): ?>
      <audio controls style="width:100%;margin-top:8px;">
        <source src="<?= htmlspecialchars($signed) ?>">
      </audio>
    <?php else: ?>
      <video controls style="width:100%;margin-top:8px;">
        <source src="<?= htmlspecialchars($signed) ?>">
      </video>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
</div>

<?php include __DIR__ . "/_footer.php"; ?>
