<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Global Media Player</title>
  <link rel="stylesheet" href="/app/style.css">
</head>
<body>
  <div class="container">
    <img src="/img/logo.png" class="logo" alt="NETID Logo">
