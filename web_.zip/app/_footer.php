    <footer style="margin-top:22px;font-size:12px;color:#b2bec3;">
      &copy; 2025 NETID PROJECT
    </footer>
  </div>
</body>
</html>
