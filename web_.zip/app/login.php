<?php
require_once __DIR__ . "/config.php";
include __DIR__ . "/_header.php";

$err = "";
$registered = isset($_GET['registered']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? "");
  $pw    = $_POST['password'] ?? "";

  $stmt = db()->prepare("SELECT id, password_hash, name FROM users WHERE email=?");
  $stmt->execute([$email]);
  $user = $stmt->fetch();

  if (!$user || !password_verify($pw, $user['password_hash'])) {
    $err = "이메일 또는 비밀번호가 올바르지 않습니다.";
  } else {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    header("Location: /app/player.php");
    exit;
  }
}
?>

<h1>로그인</h1>

<?php if ($registered): ?>
  <div class="alert">가입이 완료되었습니다. 로그인 해주세요.</div>
<?php endif; ?>
<?php if ($err): ?>
  <div class="alert"><?= htmlspecialchars($err) ?></div>
<?php endif; ?>

<form method="post">
  <label>이메일</label>
  <input type="email" name="email" required>

  <label>비밀번호</label>
  <input type="password" name="password" required>

  <button class="btn" type="submit">로그인</button>
</form>

<p>
  계정이 없나요? <a class="small-link" href="/app/register.php">회원가입</a>
</p>

<?php include __DIR__ . "/_footer.php"; ?>
