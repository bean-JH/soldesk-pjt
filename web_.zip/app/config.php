<?php
// DB
define('DB_HOST', 'stack2-ec2-myrdsinstance-nluqhlp1pywi.cdmos8wg6g75.ap-northeast-2.rds.amazonaws.com');  // RDS 엔드포인트
define('DB_NAME', 'media_service');
define('DB_USER', 'root');
define('DB_PASS', 'password');

function db() {
  static $pdo = null;
  if ($pdo === null) {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
  }
  return $pdo;
}
