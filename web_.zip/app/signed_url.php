<?php
use Aws\CloudFront\CloudFrontClient;

require_once __DIR__ . "/vendor/autoload.php";

define('CF_DOMAIN', 'https://cdn.soldesk.cloud');    // CloudFront 도메인
define('CF_KEY_PAIR_ID', 'K1B9VOIPLBWA5U');          // KeyPair ID
define('CF_PRIVATE_KEY_PATH', '/var/www/keys/cf_private_key.pem');

function cloudfront_signed_url($path, $expiresInSec = 3600) {
  $client = new CloudFrontClient([
    'version' => 'latest',
    'region'  => 'us-east-1' // CloudFront는 리전 의미 없지만 SDK 필요
  ]);

  $resourceUrl = CF_DOMAIN . $path;
  $expires = time() + $expiresInSec;

  $privateKey = file_get_contents(CF_PRIVATE_KEY_PATH);

  return $client->getSignedUrl([
    'url'         => $resourceUrl,
    'expires'     => $expires,
    'private_key' => $privateKey,
    'key_pair_id' => CF_KEY_PAIR_ID,
  ]);
}
