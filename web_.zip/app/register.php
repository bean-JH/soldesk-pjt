<?php
require_once __DIR__ . "/config.php";
include __DIR__ . "/_header.php";

$err = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? "");
  $name  = trim($_POST['name'] ?? "");
  $pw    = $_POST['password'] ?? "";
  $pw2   = $_POST['password2'] ?? "";

  if (!$email || !$name || !$pw) $err = "모든 항목을 입력하세요.";
  else if ($pw !== $pw2) $err = "비밀번호가 일치하지 않습니다.";
  else {
    try {
      $stmt = db()->prepare("INSERT INTO users(email, password_hash, name) VALUES (?,?,?)");
      $stmt->execute([$email, password_hash($pw, PASSWORD_BCRYPT), $name]);
      header("Location: /app/login.php?registered=1");
      exit;
    } catch (PDOException $e) {
      if (str_contains($e->getMessage(), "Duplicate")) $err = "이미 등록된 이메일입니다.";
      else $err = "가입 오류: " . $e->getMessage();
    }
  }
}
?>

<h1>회원가입</h1>

<?php if ($err): ?>
  <div class="alert"><?= htmlspecialchars($err) ?></div>
<?php endif; ?>

<form method="post">
  <label>이메일</label>
  <input type="email" name="email" required>

  <label>이름</label>
  <input type="text" name="name" required>

  <label>비밀번호</label>
  <input type="password" name="password" required>

  <label>비밀번호 확인</label>
  <input type="password" name="password2" required>

  <button class="btn" type="submit">가입하기</button>
</form>

<p>
  이미 계정이 있나요? <a class="small-link" href="/app/login.php">로그인</a>
</p>

<?php include __DIR__ . "/_footer.php"; ?>
