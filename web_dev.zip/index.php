<?php /* landing only */ ?>
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>작업 관리 시스템</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <style>
    :root{
      --bg: #e9eef7;
      --card: #ffffff;
      --text: #0f172a;
      --muted: #64748b;

      --primary: #1d4ed8;
      --primary-2: #2563eb;

      --shadow: 0 12px 40px rgba(15, 23, 42, 0.12);
      --radius: 18px;
      --radius2: 22px;
    }
    *{ box-sizing: border-box; }
    body{
      margin:0;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, "Noto Sans KR", Arial, sans-serif;
      background: linear-gradient(#eef3fb, #e6ecf8);
      color: var(--text);
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
    a{ text-decoration:none; color:inherit; }

    .page{
      max-width: 1040px;
      margin: 0 auto;
      padding: 18px 18px 40px;
    }

    .topbar{
      position: sticky;
      top:0;
      z-index: 50;
      background: rgba(255,255,255,0.75);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(148,163,184,0.35);
    }
    .topbar__inner{
      max-width: 1040px;
      margin: 0 auto;
      padding: 14px 18px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap: 12px;
    }
    .brand{
      font-weight: 800;
      color:#1e3a8a;
      letter-spacing: -0.2px;
      font-size: 18px;
      white-space: nowrap;
    }

    .btn{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      padding: 10px 16px;
      border-radius: 10px;
      border: 1px solid transparent;
      font-weight: 700;
      cursor:pointer;
      transition: transform .08s ease, background .15s ease, border-color .15s ease;
      user-select:none;
      white-space: nowrap;
      -webkit-tap-highlight-color: transparent;
    }
    .btn:active{ transform: translateY(1px); }
    .btn--primary{
      background: var(--primary);
      color:#fff;
      box-shadow: 0 10px 24px rgba(37, 99, 235, 0.28);
    }
    .btn--primary:hover{ background: var(--primary-2); }

    .hero-card{
      background: rgba(255,255,255,0.55);
      border: 1px solid rgba(148,163,184,0.35);
      border-radius: var(--radius2);
      box-shadow: var(--shadow);
      overflow:hidden;
    }

    /* ✅ hero 높이/크기 유지 + 이미지만 교체 */
    .hero{
      position:relative;
      height: clamp(260px, 34vh, 360px);
      border-bottom: 1px solid rgba(148,163,184,0.25);
      background:
        linear-gradient(90deg, rgba(2,6,23,0.15), rgba(2,6,23,0.12)),
        url("https://media.licdn.com/dms/image/v2/D4E05AQFJaJ7lvc1d5A/videocover-low/B4EZmgBgVFKoB8-/0/1759326431750?e=2147483647&v=beta&t=VAgfZQOZc43tAKhaDl77eUTBhIOybkCGAdkmqn_eTic")
        center/cover no-repeat;
    }

    .hero__content{
      position:absolute;
      inset:0;
      display:flex;
      flex-direction:column;
      align-items:center;
      justify-content:center;
      text-align:center;
      padding: 24px;
      color:#fff;
    }
    .hero__content h1{
      margin:0;
      font-size: clamp(26px, 4.2vw, 54px);
      font-weight: 900;
      letter-spacing: -0.7px;
      text-shadow: 0 10px 22px rgba(2,6,23,0.35);
      line-height: 1.15;
    }
    .hero__content p{
      margin: 10px 0 18px;
      max-width: 760px;
      font-size: 15.5px;
      color: rgba(255,255,255,0.88);
      text-shadow: 0 8px 18px rgba(2,6,23,0.25);
      line-height: 1.55;
    }

    .btn--hero{
      background: rgba(29, 78, 216, 0.92);
      color:#fff;
      padding: 12px 28px;
      border-radius: 12px;
      box-shadow: 0 14px 30px rgba(29, 78, 216, 0.35);
    }
    .btn--hero:hover{ background: rgba(37, 99, 235, 0.95); }

    .features{
      padding: 26px 22px 26px;
      background: rgba(239, 244, 252, 0.75);
    }
    .features h2{
      margin: 6px 0 18px;
      text-align:center;
      font-size: 22px;
      letter-spacing: -0.3px;
    }

    .cards{
      display:grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 14px;
      align-items: stretch;
    }

    .card{
      background: rgba(255,255,255,0.92);
      border: 1px solid rgba(148,163,184,0.35);
      border-radius: 14px;
      padding: 18px 16px 16px;
      box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
      min-height: 220px;
      display:flex;
      flex-direction:column;
      align-items:center;
      text-align:center;
    }
    .card__icon{
      position:relative;
      width: 76px;
      height: 76px;
      border-radius: 18px;
      background: rgba(219, 234, 254, 0.9);
      display:flex;
      align-items:center;
      justify-content:center;
      margin-bottom: 10px;
      border: 1px solid rgba(147,197,253,0.8);
      flex: 0 0 auto;
    }
    .card__icon i{
      font-size: 40px;
      color: #2563eb;
    }
    .badge{
      position:absolute;
      width: 26px;
      height: 26px;
      border-radius: 999px;
      display:flex;
      align-items:center;
      justify-content:center;
      bottom: -6px;
      right: -6px;
      box-shadow: 0 8px 18px rgba(2,6,23,0.18);
      border: 2px solid #fff;
    }
    .badge--plus{ background:#1d4ed8; }
    .badge--paper{ background:#38bdf8; }
    .badge--check{ background:#22c55e; }
    .badge i{ font-size: 14px; color:#fff; }

    .card h3{
      margin: 6px 0 8px;
      font-size: 18px;
      font-weight: 900;
      letter-spacing: -0.2px;
    }
    .card p{
      margin:0;
      color: var(--muted);
      font-size: 13.5px;
      line-height: 1.6;
    }

    .footer{
      padding: 18px 0 26px;
      color: rgba(15,23,42,0.55);
    }
    .footer__inner{
      max-width: 1040px;
      margin: 0 auto;
      padding: 0 18px;
      display:flex;
      justify-content:center;
    }

    @media (max-width: 980px){
      .cards{ grid-template-columns: repeat(2, 1fr); }
    }

    @media (max-width: 640px){
      .page{ padding: 14px 14px 34px; }
      .topbar__inner{ padding: 12px 14px; }

      .hero__content{ padding: 18px; }
      .hero__content p{ font-size: 14.5px; }

      .features{ padding: 20px 14px 22px; }
      .features h2{ font-size: 20px; }

      .cards{
        grid-template-columns: 1fr;
        gap: 12px;
      }

      .card{
        width: 100%;
        max-width: 520px;
        margin: 0 auto;
        min-height: auto;
      }

      .btn--hero{ padding: 12px 22px; }
    }
  </style>
</head>

<body>
  <header class="topbar">
    <div class="topbar__inner">
      <div class="brand">작업 관리 시스템</div>
      <a class="btn btn--primary" href="login.php">로그인</a>
    </div>
  </header>

  <main class="page">
    <section class="hero-card">
      <div class="hero">
        <div class="hero__content">
          <h1>건설 프로젝트를 손쉽게 관리하세요!</h1>
          <p>효율적으로 작업을 관리하고, 할당량 및 작업 결과를 간편하게 확인하세요.</p>
          <a class="btn btn--hero" href="login.php">로그인</a>
        </div>
      </div>

      <div class="features">
        <h2>이 시스템에서 할 수 있는 일</h2>

        <div class="cards">
          <article class="card">
            <div class="card__icon">
              <i class="bi bi-clipboard2-check"></i>
              <span class="badge badge--plus"><i class="bi bi-plus-lg"></i></span>
            </div>
            <h3>작업 할당</h3>
            <p>관리자는 작업 내용과 현장 사진을 등록하여 작업자에게 할당합니다.</p>
          </article>

          <article class="card">
            <div class="card__icon">
              <i class="bi bi-camera"></i>
              <span class="badge badge--paper"><i class="bi bi-file-earmark-text"></i></span>
            </div>
            <h3>작업 결과 제출</h3>
            <p>작업자는 할당된 작업을 확인한 후 결과 사진과 작업 결과 내용을 시스템에 제출할 수 있습니다.</p>
          </article>

          <article class="card">
            <div class="card__icon">
              <i class="bi bi-bell"></i>
              <span class="badge badge--check"><i class="bi bi-check-lg"></i></span>
            </div>
            <h3>작업 승인 및 현황 관리</h3>
            <p>관리자는 제출된 결과를 검토하고 승인함으로써 작업 진행 상황과 실적을 관리합니다.</p>
          </article>
        </div>
      </div>
    </section>
  </main>

  <footer class="footer">
    <div class="footer__inner">© <?php echo date('Y'); ?> 작업 관리 시스템</div>
  </footer>
</body>
</html>
