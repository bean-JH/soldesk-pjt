<?php
require_once "auth_guard.php";
require_once "db.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  header("Location: dashboard.php");
  exit;
}

/* ✅ 관리자만 등록 허용 */
$role = $_SESSION["role"] ?? ($_SESSION["user_role"] ?? "worker");
if ($role !== "admin") {
  http_response_code(403);
  echo "Forbidden";
  exit;
}

$title = trim($_POST["title"] ?? "");
$desc  = trim($_POST["description"] ?? "");
$date  = trim($_POST["task_date"] ?? "");

if ($title === "" || $desc === "" || $date === "") {
  header("Location: dashboard.php");
  exit;
}

/* ✅ 사진 업로드: 일단 로컬 폴더 uploads/tasks/ 에 저장 */
$photoUrl = null;

if (isset($_FILES["photos"]) && isset($_FILES["photos"]["tmp_name"]) && is_array($_FILES["photos"]["tmp_name"])) {
  $tmp = $_FILES["photos"]["tmp_name"][0] ?? "";
  $err = $_FILES["photos"]["error"][0] ?? UPLOAD_ERR_NO_FILE;

  if ($err === UPLOAD_ERR_OK && is_uploaded_file($tmp)) {
    // 간단 검증(이미지인지)
    $info = @getimagesize($tmp);
    if ($info !== false) {
      $ext = image_type_to_extension($info[2], false); // jpg/png/webp...
      if (!in_array($ext, ["jpg","jpeg","png","webp","gif"], true)) $ext = "jpg";

      $dir = __DIR__ . "/uploads/tasks";
      if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
      }

      $filename = "task_" . date("Ymd_His") . "_" . bin2hex(random_bytes(6)) . "." . $ext;
      $dest = $dir . "/" . $filename;

      if (move_uploaded_file($tmp, $dest)) {
        // 브라우저에서 접근할 경로(상대경로)
        $photoUrl = "uploads/tasks/" . $filename;
      }
    }
  }
}

/* ✅ DB 저장 */
$stmt = $pdo->prepare("
  INSERT INTO tasks (title, description, task_date, photo_url, created_by)
  VALUES (?, ?, ?, ?, ?)
");
$stmt->execute([
  $title,
  $desc,
  $date,
  $photoUrl,
  (int)($_SESSION["user_id"] ?? 0)
]);

header("Location: dashboard.php");
exit;
